package com.example.csvupload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CsvuploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(CsvuploadApplication.class, args);
	}

}
