package com.example.csvupload.controller;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.csvupload.model.Product;

@Controller
public class ProductController {
	private static final String CSV_FILE_PATH = "products.csv";
    private List<Product> products = new ArrayList<>();

    @GetMapping("/")
    public String showForm() {
    	System.out.println("inex page");
        return "homepage";
    }

    @PostMapping("/submit")
    public String submitForm(@RequestParam String productId,
                             @RequestParam String productName,
                             @RequestParam String productDescription) {
        // Set flag to 1 for all fields
        String flag = "1";
        products.add(new Product(productId, productName, productDescription, flag));
        saveToCSV(new Product(productId, productName, productDescription, flag));
        return "redirect:/";
    }

    private void saveToCSV(Product product) {
    	 try (FileWriter writer = new FileWriter(CSV_FILE_PATH, true)) {
    	        writer.append(product.toCSV()).append("\n");
    	    } catch (IOException e) {
    	        e.printStackTrace();
    	    }
    }

    @GetMapping("/display")
    public String displayData(Model model) {
        // Read CSV file and fetch data with flag = 1
        // Assuming CSV file format: productId,productName,productDescription,flag
        List<Product> filteredProducts = filterProductsByFlag("1");
        model.addAttribute("products", filteredProducts);
        return "display-product";
    }

    private List<Product> filterProductsByFlag(String flag) {
        
        List<Product> filteredProducts = new ArrayList<>();
        System.out.println("Start reading CSV file");
        // Read CSV file, parse data with flag set to 1, and add to productList
        try (BufferedReader br = new BufferedReader(new FileReader(CSV_FILE_PATH))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (Integer.parseInt(data[3]) == 1) {
                	filteredProducts.add(new Product(data[0], data[1], data[2],data[3]));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("end read products from file"+filteredProducts);
        return filteredProducts;
    }
}
