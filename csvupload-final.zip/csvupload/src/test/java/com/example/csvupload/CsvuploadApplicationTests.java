package com.example.csvupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CsvuploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
